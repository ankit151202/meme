let allProducts = [];

async function fetchProducts() {
    try {
        const response = await fetch('https://fakestoreapi.com/products');
        return await response.json();
    } catch (error) {
        console.error('Error fetching products:', error);
        return [];
    }
}

function createProductCard(product) {
    return `
        <div class="product-card">
            <img src="${product.image}" alt="${product.title}" class="product-image">
            <div class="product-info">
                <h2 class="product-title">${product.title}</h2>
                <p class="product-description">${product.description}</p>
                <div class="product-details">
                    <span class="product-price">$${product.price}</span>
                    <span class="product-rating">⭐ ${product.rating.rate} (${product.rating.count})</span>
                </div>
                <span class="product-category">${product.category}</span>
            </div>
        </div>
    `;
}

function displayProducts(products) {
    const productsContainer = document.querySelector('#productsContainer');
    productsContainer.innerHTML = products
        .map(product => createProductCard(product))
        .join('');
}

function filterProducts(searchTerm) {
    const filteredProducts = allProducts.filter(product => 
        product.title.toLowerCase().includes(searchTerm) ||
        product.description.toLowerCase().includes(searchTerm) ||
        product.category.toLowerCase().includes(searchTerm)
    );
    displayProducts(filteredProducts);
}

function setupSearch() {
    const searchInput = document.querySelector('#searchInput');
    searchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        filterProducts(searchTerm);
    });
}

async function initializeApp() {
    allProducts = await fetchProducts();
    displayProducts(allProducts);
    setupSearch();
}

// Start the application
initializeApp();