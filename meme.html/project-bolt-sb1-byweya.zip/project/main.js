import './style.css';
import { fetchProducts } from './src/api/products.js';
import { createProductCard } from './src/components/productCard.js';
import { setupSearch } from './src/components/searchBar.js';

let allProducts = [];

async function initializeApp() {
  allProducts = await fetchProducts();
  displayProducts(allProducts);
  setupSearch(filterProducts);
}

function displayProducts(products) {
  const productsContainer = document.querySelector('#productsContainer');
  productsContainer.innerHTML = products
    .map(product => createProductCard(product))
    .join('');
}

function filterProducts(searchTerm) {
  const filteredProducts = allProducts.filter(product => 
    product.title.toLowerCase().includes(searchTerm) ||
    product.description.toLowerCase().includes(searchTerm) ||
    product.category.toLowerCase().includes(searchTerm)
  );
  displayProducts(filteredProducts);
}

document.querySelector('#app').innerHTML = `
  <nav class="navbar">
    <div class="logo">
      <h1>Product Search</h1>
    </div>
    <div class="search-container">
      <input type="text" id="searchInput" placeholder="Search products...">
    </div>
  </nav>
  <main id="productsContainer" class="products-container"></main>
`;

initializeApp();