export function createProductCard(product) {
  return `
    <div class="product-card">
      <img src="${product.image}" alt="${product.title}" class="product-image" loading="lazy">
      <div class="product-info">
        <h2 class="product-title">${product.title}</h2>
        <p class="product-description">${product.description}</p>
        <div class="product-details">
          <span class="product-price">$${product.price.toFixed(2)}</span>
          <span class="product-rating">⭐ ${product.rating.rate} (${product.rating.count})</span>
        </div>
        <span class="product-category">${product.category}</span>
      </div>
    </div>
  `;
}