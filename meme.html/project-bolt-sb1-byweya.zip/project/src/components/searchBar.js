export function setupSearch(onSearch) {
  const searchInput = document.querySelector('#searchInput');
  
  let debounceTimeout;
  
  searchInput.addEventListener('input', (e) => {
    clearTimeout(debounceTimeout);
    debounceTimeout = setTimeout(() => {
      onSearch(e.target.value);
    }, 300);
  });
}