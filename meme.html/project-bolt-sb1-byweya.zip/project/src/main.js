import './style.css';
import { fetchProducts } from './api/products.js';
import { createProductCard } from './components/productCard.js';
import { setupSearch } from './components/searchBar.js';

let allProducts = [];

function displayProducts(products) {
  const productsContainer = document.querySelector('#productsContainer');
  if (products.length === 0) {
    productsContainer.innerHTML = '<div class="no-results">No products found</div>';
    return;
  }
  productsContainer.innerHTML = products
    .map(product => createProductCard(product))
    .join('');
}

function filterProducts(searchTerm) {
  const filteredProducts = allProducts.filter(product => 
    product.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    product.category.toLowerCase().includes(searchTerm.toLowerCase())
  );
  displayProducts(filteredProducts);
}

async function initializeApp() {
  try {
    allProducts = await fetchProducts();
    displayProducts(allProducts);
    setupSearch(filterProducts);
  } catch (error) {
    console.error('Failed to initialize app:', error);
    document.querySelector('#productsContainer').innerHTML = 
      '<p class="error-message">Failed to load products. Please try again later.</p>';
  }
}

// Start the application
initializeApp();